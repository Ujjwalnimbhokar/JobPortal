<?php
include('connection/db.php');
$category = $_POST['category'];
$description = $_POST['Description'];

$query = mysqli_query($conn, "insert into job_category(category, des) values('$category','$description')");
if($query){
    echo"<script>alert('Record inserted Successfully')</script>"; 
    header('location:http://localhost/Jobportal/admin/category.php');
}
else
{
    echo"<script>alert('Record failed to inserted')</script>";
}
?>