
<?php
include('connection/db.php');

    $id=$_POST['id'];
    $email=$_POST['email'];
    $Username=$_POST['Username'];
    $Password=$_POST['Password'];
    $first_name=$_POST['first_name'];
    $last_name=$_POST['last_name'];
    $admin_type=$_POST['admin_type'];
    
    $query= mysqli_query($conn, "update admin_login set admin_email='$email' , admin_username='$Username',
    admin_pass='$Password', first_name='$first_name' ,last_name ='$last_name', admin_type='$admin_type' where id='$id'");

    if($query){
        echo"<script>alert('Record has been Updated Successfully ')</script>";
        header('location:http://localhost/Jobportal/Admin/Customers.php');
    }
    else{
        echo"<script>alert('Record has not Updated Successfully')</script>";
    }
?>