$("document").ready(function(){
$("#submit").click(function(){
    var email = $("#")
})    

});