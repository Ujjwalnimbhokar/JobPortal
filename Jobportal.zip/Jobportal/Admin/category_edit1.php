<?php
include('connection/db.php');
if(isset($_POST['submit']))
{
    $id=$_POST['id'];
    $category=$_POST['category'];
    $des=$_POST['des'];
   
    $query= mysqli_query($conn, "update job_category set category='$category' , des='$des' where id='$id'");
    if($query)
    {
        echo"<script>alert('Record has  Updated Successfully ')</script>";
        header('location:http://localhost/Jobportal/admin/category.php');
    }
    else{
        echo"<script>alert('Some error Please Try again')</script>";
    }
}
?>