
<?php
$username = "root";
$pass = "";
$server = "localhost";
$db="jobportal";

$conn = mysqli_connect($server,$username,$pass,$db);

?>