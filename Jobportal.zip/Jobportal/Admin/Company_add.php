<?php
include('connection/db.php');
$Company = $_POST['Company'];
$description = $_POST['Description'];
$customer_email = $_POST['admin_email'];


$query = mysqli_query($conn, "insert into company(company, des,customer_email) values('$Company','$description','$customer_email')");
if($query){
    echo"<script>alert('Record inserted Successfully')</script>"; 
    header('location:create_company.php');
}
else
{
    echo"<script>alert('Record failed to inserted')</script>";
}
?>