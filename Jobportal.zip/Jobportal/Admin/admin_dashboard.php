
<?php 
    include("include/header.php");
    include("include/sidebar.php")
?>
    <!-- PIE CHART -->
    <div>
    <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title" style="margin-left: 6cm;">Total Jobs (Sector wise)</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>

                </div>
              </div>
              <div class="card-body">
                <canvas id="pieChartStudYearWise" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 97%; margin-left:2cm"></canvas>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
</div></div>


            <!-- PIE CHART -->
            <div>
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title" style="margin-left:6cm">Total Categories (Industry wise)</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>

                </div>
              </div>
              <div class="card-body">
                <canvas id="pieChartYearWise" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 97%; margin-left:2cm" ></canvas>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
</div>
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <script src="js/bootstrap.min.js"></script>
    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.1/dist/Chart.min.js"></script>
    <script>


$(function () {
    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartStudYearWiseCanvas = $('#pieChartStudYearWise').get(0).getContext('2d')
    var pieChartYearWiseCanvas = $('#pieChartYearWise').get(0).getContext('2d')


    var pieDataStudYearWise        = {
      labels: [
          'Manager',
          'Assistant',
          'Specialist',
          'Technician',
          'Designer',
          'Analyst',
          'Officer',
          'Engineer'
      ],
      datasets: [
        {
          data: [27, 5 , 3, 5, 10, 10, 5, 10], 
          backgroundColor : [ '#d2d6de', '#e1ebf4', '#a6c4dd', '#00c0ef', '#3c8dbc', '#26455a', '#1d2f3c', '#767f86'],
        }
      ]
    }

    var pieDataYearWise        = {
      labels: [
          'Textual and apparel manufacturing',
          'Wholesale/Retail',
          'Food and beverage manufacturing',
          'Agriculture and Others',
          'Hospitality'
        
      ],
      datasets: [
        {
          data: [9,7,6,10,9],
          backgroundColor : ['#7c8184', '#5cb85c', '#f0ad4e', '#d9534f', '#d2d6de'],
          
        }
      ]
    }


    
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(pieChartStudYearWiseCanvas, {
      type: 'pie',
      data: pieDataStudYearWise,
      options: pieOptions
    })

    new Chart(pieChartYearWiseCanvas, {
      type: 'pie',
      data: pieDataYearWise,
      options: pieOptions
    })


    

  })

    </script>  </body>
</html>
