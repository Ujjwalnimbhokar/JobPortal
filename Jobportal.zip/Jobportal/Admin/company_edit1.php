<?php
include('connection/db.php');
if(isset($_POST['submit']))
{
    $id=$_POST['id'];
    $company=$_POST['Company'];
    $des=$_POST['des'];
    $customer_email=$_POST['admin_email'];
    
    $query= mysqli_query($conn, "update company set company='$company' , des='$des' , customer_email='$customer_email' where company_id='$id'");

    if($query)
    {
        echo"<script>alert('Record has  Updated Successfully ')</script>";
        header('location:create_company.php');
    }
    else{
        echo"<script>alert('Some error Please Try again')</script>";
    }
}