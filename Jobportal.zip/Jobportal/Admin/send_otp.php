<?php
 include('connection/db.php');
 $email=$_POST['email'];
 $msg=$_POST['body'];
 $res=mysqli_query($conn,"select * from job_apply where job_seeker='$email'");
 $count=mysqli_num_rows($res);
 if($count>0)
 {
    $otp=rand(11111,99999);
   $html="Your otp verification code is ".$html;
   smtp_mailer($email,$msg, $html); 
 }
 else{
    echo "not_exist";
 }

 function smtp_mailer($to, $subject, $msg)
 {
   require_once("smtp/class.phpmailer.php");
   $mail=new PHPMailer();
   $mail->IsSMTP();
   $mail->SMTPDebug=1;
   $mail->SMTPAuth=true;
   $mail->SMTPSecure='TLS';
   $mail->HOST="localhost";
   $mail->Port=3306;
   $mail->IsHTML(true);
   $mail->Charset='UTF-8';
   $mail->Username=$_POST['email'];
   
 }
?>