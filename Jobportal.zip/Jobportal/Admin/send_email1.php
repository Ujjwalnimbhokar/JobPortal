<?php
 include('connection/db.php');
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
        use PHPMailer\PHPMailer\Exception;
        require '../vendor/autoload.php';
       
        function sendemail_verify($email,$name,$body)
        {

                $mail = new PHPMailer(); // create a new object
                $mail->IsSMTP(); // enable SMTP
                $mail->SMTPDebug = 0; // debugging: 1 = errors and messages, 2 = messages only
                $mail->SMTPAuth = true; // authentication enabled
                $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
                $mail->Host = "smtp.gmail.com";
                $mail->Port = 465; // or 587
                $mail->IsHTML(true);
                $mail->Username = $name;
                $mail->Password = "aygvqppvhqltlrzr";
                $mail->SetFrom($email);
                $mail->Subject = "Test";
                $mail->Body = $body;
                $mail->AddAddress($email);

                if(!$mail->Send()) 
                {
                    echo "Mailer Error: " . $mail->ErrorInfo;
                } 
                else 
                {
                    echo "Message has been sent";
                } 
        }
    if(isset($_POST['submit']))
    {    
    $email=$_POST['email'];
    $name=$_POST['sender'];
    $body=$_POST['body'];;
    sendemail_verify($email,$name,$body);
}
?>