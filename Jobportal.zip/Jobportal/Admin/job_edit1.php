<?php
include('connection/db.php');
if(isset($_POST['submit']))
{
    $id=$_POST['id'];
    $job_title=$_POST['job_title'];
    $Description=$_POST['Description'];
    $country=$_POST['country'];
    $state=$_POST['state'];
    $city=$_POST['city'];
    
    $query= mysqli_query($conn, "update all_jobs set job_title='$job_title' , des='$Description',
    country='$country', state='$state' ,city ='$city' where job_id='$id'");

    if($query)
    {
        echo"<script>alert('Record has  Updated Successfully ')</script>";
        header('location:Job_create.php');
    }
    else{
        echo"<script>alert('Some error Please Try again')</script>";
    }
}
?>