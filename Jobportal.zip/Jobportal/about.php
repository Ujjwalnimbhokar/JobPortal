<?php
$page='about';
session_start();
  include("include/header.php");  
?>

    
    <!-- END nav -->
    
    

      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start" data-scrollax-parent="true">
          <div class="col-md-8 ftco-animate text-center text-md-left mb-5" data-scrollax=" properties: { translateY: '70%' }">
          	<p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-3"><a href="index.html">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>About</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">About</h1>
          </div>
        </div>
      </div>
    </div>
<div>
<hr class="featurette-divider">
    <section class="ftco-about d-md-flex">
    	<div class="one-half img" style="background-image: url(images/about.jpg);"></div>
    	<div class="one-half ftco-animate">
        <div class="heading-section ftco-animate ">
          <h2 class="mb-4"><span>We Are The Job Portal Agency</span></h2>
        </div>
        <div>
  				<p>A job portal is a website that lists job openings from a variety of employers. Job portals are a great way to find new job opportunities, and they can be used by both job seekers and employers.

When choosing a job portal, it is important to consider the following factors:

The type of jobs you are looking for
The size of the job board
The features offered by the job board
The cost of the job board
Once you have chosen a job portal, you can start your job search by creating a profile and searching for jobs that match your skills and interests. You can also sign up for email alerts so that you are notified when new jobs are posted.

Here are some tips for using job portals to find a job:

Use keywords in your search to narrow down the results.
Read the job descriptions carefully to make sure you are qualified for the position.
Tailor your resume and cover letter to each job you apply for.
Follow up with the employer after you apply.
Job portals can be a great way to find a new job. By following the tips above, you can increase your chances of success in your job search.

Here are some additional tips for using job portals:

Use multiple job portals to increase your chances of finding a job.
Network with people in your field to learn about job opportunities that may not be listed on job portals.
Attend job fairs to meet with potential employers.
Don't give up! The job search can be tough, but it is important to stay positive and keep trying</p>
  			</div>
    	</div>
    </section>
</div>
<hr class="featurette-divider">
		
    <?php
  include("include/footer.php");

  ?>