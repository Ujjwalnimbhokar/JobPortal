
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Signin Template for Bootstrap</title>

    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css">
  </head>

  <body class="text-center">
    <form class="form-signin" action="sign_up.php" method="post">
    <img class="mb-4" src="images/job.jpg" alt="" width="72" height="72">
      <h1 class="h3 mb-3 font-weight-normal">Please sign up</h1>

      <!-- <label for="inputEmail" class="sr-only">Email address</label> -->
      <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email address" required autofocus >

      <!-- <label for="inputPassword" class="sr-only">Password</label> -->
      <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required autofocus>

      <!-- <label for="inputEmail" class="sr-only">First Name</label> -->
      <input type="text" id="first_name" class="form-control" name="first_name" placeholder="Enter First Name" required autofocus>

      <!-- <label for="inputEmail" class="sr-only">Last Name</label> -->
      <input type="text" id="last_name" name="last_name" class="form-control" placeholder="Enter Last Name" required autofocus>

     <!-- <label for="inputEmail" class="sr-only">Mobile Number</label> -->
      <input type="Number" id="mobile_number" class="form-control" name="mobile_number" placeholder="Enter Mobile Number" required autofocus>

      <!-- <label for="inputEmail" class="sr-only">Date of Birth</label> -->
      <input type="date" id="dob" class="form-control" name="dob" placeholder="Enter Your  Date of Birth" required autofocus>
       <br>
      <input  class="btn btn-lg btn-primary btn-block" name="submit" value="sign up" type="submit"> <br>
      <a href="job-post.php">Alredy Account</a>
      <p class="mt-5 mb-3 text-muted">&copy; 2022-2023</p>
    </form>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>

<?php

include('connection/db.php');

if(isset($_POST['submit']))
{
 echo $email=$_POST['email'];
 echo $pass=$_POST['password'];
 echo $first_name=$_POST['first_name'];
 echo $last_name=$_POST['last_name'];
 echo $dob=$_POST['dob'];
 echo $mobile_num=$_POST['mobile_number'];

$query=mysqli_query($conn,"insert into jobskeer(email,password,first_name,last_name,dob,mobile_number) values('$email','$pass','$first_name', 
                    '$last_name','$dob','$mobile_num')");

if($query)
{
    echo "<script>alert('Now you can login')</script>";
    header('location:job-post.php');
}
else
{
    echo "<script>alert('Some error please try agin')</script>";
}

}

?>